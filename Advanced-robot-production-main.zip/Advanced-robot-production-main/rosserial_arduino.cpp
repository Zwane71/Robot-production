#include <ros.h>
#include <std_msgs/String.h>

ros::NodeHandle nh;

void motorControlCallback(const std_msgs::String &msg) {
  // Parse and use the motor command from msg.data
}

ros::Subscriber<std_msgs::String> sub("motor_commands", motorControlCallback);

void setup() {
  nh.initNode();
  nh.subscribe(sub);
}

void loop() {
  nh.spinOnce();
  delay(10);
}
