import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix, Temperature, Humidity
import paho.mqtt.client as mqtt

class WaziCloudNode(Node):
    def __init__(self):
        super().__init__('wazi_cloud_node')
        self.client = mqtt.Client()
        self.client.connect("your_wazicloud_broker_url", 1883, 60)
        self.create_subscription(NavSatFix, 'gps/fix', self.gps_callback, 10)
        self.create_subscription(Temperature, 'environment/temperature', self.temp_callback, 10)
        self.create_subscription(Humidity, 'environment/humidity', self.humidity_callback, 10)

    def gps_callback(self, msg):
        # Format GPS data and publish to WaziCloud
        self.client.publish("wazi/gps", f"{msg.latitude},{msg.longitude},{msg.altitude}")

    def temp_callback(self, msg):
        # Format temperature data and publish to WaziCloud
        self.client.publish("wazi/temperature", f"{msg.temperature}")

    def humidity_callback(self, msg):
        # Format humidity data and publish to WaziCloud
        self.client.publish("wazi/humidity", f"{msg.relative_humidity}")

def main(args=None):
    rclpy.init(args=args)
    node = WaziCloudNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
