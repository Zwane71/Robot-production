#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class MotorControlNode : public rclcpp::Node {
public:
  MotorControlNode() : Node("motor_control_node") {
    subscription_ = this->create_subscription<std_msgs::msg::String>(
      "motor_commands", 10, std::bind(&MotorControlNode::motorControlCallback, this, std::placeholders::_1));
  }

private:
  void motorControlCallback(const std_msgs::msg::String::SharedPtr msg) const {
    // Send commands to Arduino
  }
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_;
};

int main(int argc, char *argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MotorControlNode>());
  rclcpp::shutdown();
  return 0;
}
