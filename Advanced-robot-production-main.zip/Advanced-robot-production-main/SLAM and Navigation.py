# slam_navigation/launch/slam_navigation_launch.py
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[{'use_sim_time': False}]
        ),
        Node(
            package='nav2_bringup',
            executable='bringup_launch',
            name='nav2_bringup',
            output='screen',
            parameters=[{'use_sim_time': False}]
        ),
    ])
